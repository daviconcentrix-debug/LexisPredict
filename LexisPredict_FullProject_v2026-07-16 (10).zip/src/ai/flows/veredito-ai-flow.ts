'use server';
/**
 * @fileOverview Motor de Auditoria 3D v2400.0 ELITE
 * Núcleo: Pentade de Motores Neurais com Triagem de Dados do DataJud.
 * Motor Principal: Grok 4.5 (xAI) SOBERANO
 * Proprietário: W1 Capital | Fundador: Davi Alves Figueredo
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import {fetchDataJud} from '@/lib/datajud';

const API_KEYS = {
  XAI: 'xai-y4Cb5DsvKes9ly1aw1gJhImy5beBEifCdhKyf3vPEzQEYuPKfRKAz2r8lf8dfojh3MlMSacyE4fmayYn',
  GROQ: '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',
  AIRFORCE: 'sk-air-nYatcFeVTGb4k7acJplUa97jQhjaHRM5yWpzR3TWzvQip3Fb'
};

const SYSTEM_INSTRUCTIONS = `Você é o Veredito AI Elite do Gabinete Jurídico Get Assessoria. 
Analise os dados processuais fornecidos e retorne um parecer técnico-comercial rigoroso em JSON.

REGRAS DE OURO:
1. RESUMO DIRETO (MÁX 6 LINHAS). Seja resolutivo.
2. Defenda sempre os interesses da Assessoria e a legalidade das taxas.
3. Se houver menção a custos, cite a Cláusula 3.2 do contrato como base de cobrança.
4. Gere uma 'mensagemCliente' pronta para WhatsApp, cordial e em tom de autoridade, assinada pelo Setor Processual.
5. Se os dados forem escassos, informe que a equipe técnica está em fase de aprofundamento.

FORMATO JSON OBRIGATÓRIO:
{ 
  "resumoTecnico": "", 
  "analiseRisco": "", 
  "proximosPassos": "", 
  "mensagemCliente": "" 
}`;

function cleanJsonResponse(text: string): any {
  if (!text) return null;
  try {
    let clean = text.replace(/```json/gi, '').replace(/```/g, '').trim();
    const firstBrace = clean.indexOf('{');
    const lastBrace = clean.lastIndexOf('}');
    
    if (firstBrace !== -1 && lastBrace !== -1) {
      return JSON.parse(clean.substring(firstBrace, lastBrace + 1));
    }
    
    if (text.length > 20) {
      return { 
        resumoTecnico: text.substring(0, 300) + "...", 
        analiseRisco: "Análise baseada em Cláusula 3.2 concluída.",
        proximosPassos: "Monitoramento de sistema mantido.",
        mensagemCliente: text 
      };
    }
    return null;
  } catch (e) { 
    return null; 
  }
}

async function callNeuralEngine(context: string, preferredModel: string = 'xai') {
  const engines = [
    { 
      id: 'xai', 
      url: 'https://api.x.ai/v1/chat/completions', 
      key: API_KEYS.XAI, 
      model: 'grok-4.5',
      useJsonMode: true 
    },
    { 
      id: 'airforce', 
      url: 'https://api.airforce/v1/chat/completions', 
      key: API_KEYS.AIRFORCE, 
      model: 'deepseek-v3',
      useJsonMode: false
    },
    { 
      id: 'groq', 
      url: 'https://api.groq.com/openai/v1/chat/completions', 
      key: API_KEYS.GROQ, 
      model: 'llama-3.3-70b-versatile',
      useJsonMode: false
    }
  ];

  // Ordena para colocar o preferido no topo
  const sortedEngines = [
    engines.find(e => e.id === preferredModel) || engines[0],
    ...engines.filter(e => e.id !== preferredModel)
  ];

  for (const engine of sortedEngines) {
    try {
      const res = await fetch(engine.url, {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${engine.key}`, 
          'Content-Type': 'application/json' 
        },
        body: JSON.stringify({
          model: engine.model,
          messages: [
            { role: 'system', content: SYSTEM_INSTRUCTIONS }, 
            { role: 'user', content: context }
          ],
          response_format: engine.useJsonMode ? { type: 'json_object' } : undefined
        }),
        signal: AbortSignal.timeout(28000)
      });
      
      if (!res.ok) continue;

      const data = await res.json();
      const content = data?.choices?.[0]?.message?.content;
      const parsed = cleanJsonResponse(content);
      
      if (parsed) return { ...parsed, engineUsed: engine.id.toUpperCase() };
    } catch (e) {
      continue;
    }
  }
  return null;
}

export const vereditoAIFlow = ai.defineFlow(
  { name: 'vereditoAIFlow', inputSchema: z.any(), outputSchema: z.any() },
  async input => {
    try {
      const dataJudData = await fetchDataJud(input.cnj);
      let dataContext = "";
      
      if (dataJudData) {
        dataContext = `DADOS OFICIAIS DATAJUD: ${JSON.stringify(dataJudData).substring(0, 12000)}`;
      } else if (input.historicoBruto) {
        dataContext = `HISTÓRICO MANUAL: ${input.historicoBruto.substring(0, 12000)}`;
      } else {
        return { error: true, message: "DADOS_INSUFICIENTES" };
      }

      const result = await callNeuralEngine(dataContext, input.preferredModel || 'xai');
      
      if (result) {
        return { 
          ...result, 
          success: true, 
          dataJudRaw: dataJudData || { numeroProcesso: input.cnj, movimentos: [] }
        };
      }
      
      return { error: true, message: "FALHA_NA_CASCATA_NEURAL" };
    } catch (e) {
      return { error: true, message: "ERRO_INTERNO_CRITICO" };
    }
  }
);

export async function executarVereditoAI(input: any) {
  return await vereditoAIFlow(input);
}
