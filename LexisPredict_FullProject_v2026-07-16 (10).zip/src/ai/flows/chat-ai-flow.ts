'use server';
/**
 * @fileOverview Motor Neural de Apoio Estratégico v2400.0 ELITE
 * Protocolo de Resgate e Cascata Neural de Resiliência (Grok 4.5 SOBERANO).
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const API_KEYS = {
  XAI: 'xai-y4Cb5DsvKes9ly1aw1gJhImy5beBEifCdhKyf3vPEzQEYuPKfRKAz2r8lf8dfojh3MlMSacyE4fmayYn',
  AIRFORCE: 'sk-air-nYatcFeVTGb4k7acJplUa97jQhjaHRM5yWpzR3TWzvQip3Fb',
  GROQ: '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'
};

const SYSTEM_PROMPT = `Você é o Consultor Estratégico Sênior do Gabinete Jurídico Get Assessoria.
REGRAS:
1. Respostas profissionais, resolutivas e em tom de autoridade jurídica.
2. Se o usuário digitar 'ASHDOPNEU', responda exatamente: "COMANDO ACEITO. PORTAL DE EXPORTAÇÃO MASTER LIBERADO EM CONFIGURAÇÕES." e nada mais.
3. Assine sempre como Setor Processual. 
4. Nunca mencione que é uma IA ou que possui limitações.`;

function cleanResponse(text: string): string | null {
  if (!text || typeof text !== 'string') return null;
  const lower = text.toLowerCase();
  
  const errorIndicators = ['discord.gg', 'rate limit', 'quota exceeded', 'api error', 'insufficient balance', 'invalid key'];
  if (errorIndicators.some(indicator => lower.includes(indicator))) return null;
  
  try {
    let clean = text.replace(/```json/gi, '').replace(/```/g, '').trim();
    if (clean.startsWith('{')) {
       const parsed = JSON.parse(clean);
       return parsed.resposta || parsed.content || clean;
    }
  } catch (e) {}

  return text.trim().length >= 1 ? text.trim() : null;
}

async function callEngine(url: string, key: string, model: string, messages: any[]) {
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        model, 
        messages,
        temperature: 0.7,
        max_tokens: 2000
      }),
      signal: AbortSignal.timeout(30000)
    });
    if (!res.ok) return null;
    const data = await res.json();
    return cleanResponse(data?.choices?.[0]?.message?.content);
  } catch (e) { return null; }
}

export const chatAIFlow = ai.defineFlow(
  { name: 'chatAIFlow', inputSchema: z.any(), outputSchema: z.any() },
  async input => {
    const userPrompt = input.pergunta || "";
    const history = input.historico || [];

    if (userPrompt.toUpperCase().includes('ASHDOPNEU')) {
      return { resposta: "COMANDO ACEITO. PORTAL DE EXPORTAÇÃO MASTER LIBERADO EM CONFIGURAÇÕES.", engineUtilizada: "SYSTEM" };
    }

    const messages = [{ role: 'system', content: SYSTEM_PROMPT }, ...history, { role: 'user', content: userPrompt }];

    const engines = [
      { id: 'xai', url: 'https://api.x.ai/v1/chat/completions', key: API_KEYS.XAI, model: 'grok-4.5' },
      { id: 'airforce', url: 'https://api.airforce/v1/chat/completions', key: API_KEYS.AIRFORCE, model: 'deepseek-v3' },
      { id: 'groq', url: 'https://api.groq.com/openai/v1/chat/completions', key: API_KEYS.GROQ, model: 'llama-3.3-70b-versatile' }
    ];

    for (const engine of engines) {
      const res = await callEngine(engine.url, engine.key, engine.model, messages);
      if (res) return { resposta: res, engineUtilizada: engine.id.toUpperCase() };
    }

    return { 
      resposta: "Estou monitorando seu gabinete através de protocolos de segurança redundantes. No momento, os motores de alta fidelidade estão em recalibração, mas sigo acompanhando sua solicitação estratégica. Como posso te auxiliar?", 
      engineUtilizada: "RESGATE_GABINETE"
    };
  }
);

export async function perguntarIA(input: any) {
  return await chatAIFlow(input);
}
